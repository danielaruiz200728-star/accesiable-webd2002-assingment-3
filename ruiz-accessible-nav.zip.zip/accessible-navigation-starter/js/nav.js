document.addEventListener('DOMContentLoaded', () => {

  const navToggle = document.getElementById('nav-toggle');
  const primaryNav = document.getElementById('primary-nav');

  const servicesTrigger = document.getElementById('paints-trigger');
  const servicesMenu = document.getElementById('paints-menu');

  const resourcesTrigger = document.getElementById('drawing-trigger');
  const resourcesMenu = document.getElementById('drawing-menu');



  function setExpanded(trigger, panel, open) {
    trigger.setAttribute('aria-expanded', String(open));
    if (open) {
      panel.removeAttribute('hidden');
    } else {
      panel.setAttribute('hidden', '');
    }
  }


  /* HAMBURGER NAV */

  navToggle.addEventListener('click', () => {
    const isOpen = navToggle.getAttribute('aria-expanded') === 'true';
    setExpanded(navToggle, primaryNav, !isOpen);

    if (isOpen) {
      setExpanded(paintsTrigger, paintsMenu, false);
      setExpanded(drawingTrigger, drawingMenu, false);
    }
  });

 
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (navToggle.getAttribute('aria-expanded') === 'true') {
      setExpanded(navToggle, primaryNav, false);
      navToggle.focus();
    }
  });




  function setupDisclosure(trigger, menu, otherTrigger, otherMenu) {

    trigger.addEventListener('click', () => {
      const isOpen = trigger.getAttribute('aria-expanded') === 'true';

     
      setExpanded(otherTrigger, otherMenu, false);

      setExpanded(trigger, menu, !isOpen);
    });


    menu.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        setExpanded(trigger, menu, false);
        trigger.focus();
      }
    });

    document.addEventListener('click', (event) => {
      const clickedInside =
        trigger.contains(event.target) || menu.contains(event.target);
      if (!clickedInside && trigger.getAttribute('aria-expanded') === 'true') {
        setExpanded(trigger, menu, false);
      }
    });
  }

  setupDisclosure(paintsTrigger, paintsMenuMenu, drawingTrigger, drawingMenuMenu);
  setupDisclosure(drawingTrigger, drawingMenu, paintsTrigger, paintsMenu);

});
